ASSuite = ASSuit or {}
ASSuite.Config = ASSuit.Config or {}

--[[ !!! NE PAS TOUCHER A CE FICHIER ENTIER !!! ]]
--[[ !!! NE PAS TOUCHER A CE FICHIER ENTIER !!! ]]
--[[ !!! NE PAS TOUCHER A CE FICHIER ENTIER !!! ]]

GNLib.RequireFolder( "ass", true )

resource.AddSingleFile("materials/assicons/success.png")
resource.AddSingleFile("materials/assicons/error.png")
resource.AddSingleFile("resource/fonts/Righteous-Regular.ttf")

--[[ !!! NE PAS TOUCHER A CE FICHIER ENTIER !!! ]]
--[[ !!! NE PAS TOUCHER A CE FICHIER ENTIER !!! ]]
--[[ !!! NE PAS TOUCHER A CE FICHIER ENTIER !!! ]]



